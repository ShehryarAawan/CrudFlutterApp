import 'package:flutter/material.dart';

import 'CrudScreen.dart';

void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.5
  @override
  Widget build(BuildContext context) => MaterialApp(
    home: Crud(),
  );
}