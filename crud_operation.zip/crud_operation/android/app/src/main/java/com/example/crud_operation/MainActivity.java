package com.example.crud_operation;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
